<div class="col-md-3">
    <aside class="booking-filters booking-filters-white">
        <h3>Filter By:</h3>
        <ul class="list booking-filters-list">
            <li>
                <h5 class="booking-filters-title">Harga</h5>
                <input type="text" id="price-slider">
            </li>
            <li>
                <h5 class="booking-filters-title">Kategori</h5>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Mobil</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Motor</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Sepeda</label>
                </div>
            </li>
            <li>
                <h5 class="booking-filters-title">Bahan Bakar</h5>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Premium</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Solar</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Pertamax</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input class="i-check" type="checkbox" />Bio Solar</label>
                </div>
            </li>

        </ul>
    </aside>
</div>
