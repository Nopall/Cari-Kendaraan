<footer id="main-footer">
            <div class="container">
                <div class="row row-wrap">
                    <div class="col-md-3">
                        <a class="logo" href="index.html">
                            {{-- <img src="privasi/resources/views/template/img/logo-invert.png" alt="Image Alternative text" title="Image Title" /> --}}
                        </a>
                        <p class="mb20">Carikendaraan.id adalah Web Portal yang dibuat supaya user Lebih Mudah Mencari Kebutuhan Otomotif</p>
                        <ul class="list list-horizontal list-space">
                            <li>
                                <a class="fa fa-facebook box-icon-normal round animate-icon-bottom-to-top" href="http://facebook.com/outattackers"></a>
                            </li>
                            <li>
                                <a class="fa fa-twitter box-icon-normal round animate-icon-bottom-to-top" href="#"></a>
                            </li>
                            <li>
                                <a class="fa fa-google-plus box-icon-normal round animate-icon-bottom-to-top" href="#"></a>
                            </li>
                            <li>
                                <a class="fa fa-linkedin box-icon-normal round animate-icon-bottom-to-top" href="#"></a>
                            </li>
                        </ul>
                    </div>

                    <div class="col-md-3">
                        <h4>Newsletter</h4>
                        <form>
                            <label>Enter your E-mail Address</label>
                            <input type="text" class="form-control">
                            <p class="mt5"><small>*We Never Send Spam</small>
                            </p>
                            <input type="submit" class="btn btn-primary" value="Subscribe">
                        </form>
                    </div>
                    <div class="col-md-2">
                        <ul class="list list-footer">
                            <li><a href="./about">About US</a>
                            </li>
                            <li><a href="./police">Privacy Policy</a>
                            </li>
                            <li><a href="./terms">Terms of Use</a>
                            </li>
                            <li><a href="javascript:void(0)">Feedback</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h4>Have Questions?</h4>
                        <h4 class="text-color">+1-234-567-8910</h4>
                        <h4><a href="#" class="text-color">admin@carikendaraan.id</a></h4>
                        <p>24/7 Dedicated Customer Support</p>
                    </div>
            </div>
          </div>
        </footer>
