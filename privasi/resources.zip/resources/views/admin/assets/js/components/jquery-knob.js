/*!
 * remark v1.0.1 (http://getbootstrapadmin.com/remark)
 * Copyright 2015 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("knob", {
  mode: "default",
  defaults: {
    min: -50,
    max: 50,
    width: 120,
    height: 120,
    thickness: ".1"
  }
});
