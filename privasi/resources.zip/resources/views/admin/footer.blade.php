<footer class="site-footer">
    <span class="site-footer-legal">© 2016 Intive Studio</span>
    <div class="site-footer-right">
        Created <i class="red-600 wb wb-heart"></i> by <a href="http://intivestudio.com">Intive Studio</a>
    </div>
</footer>